import React, { useState } from 'react';
import './BookingForm.css';
import Confirmation from './Confirmation';

const BookingForm = ({ movieId = 1 }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [bookingId, setBookingId] = useState(null);

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const generatedId = Math.floor(100000 + Math.random() * 900000); // 6-digit ID
    setBookingId(generatedId);
    setIsSubmitted(true);
  };

  const handleGoHome = () => {
    setIsSubmitted(false);
    setFormData({ name: '', email: '', mobile: '' });
    setBookingId(null);
  };

  return isSubmitted ? (
    <Confirmation
      bookingId={bookingId}
      formData={formData}
      onGoHome={handleGoHome}
    />
  ) : (
    <div className="booking-container">
      <h1>
        🎬 Booking for Movie ID: <span className="highlight">{movieId}</span>
      </h1>
      <form onSubmit={handleSubmit}>
        <div className="form-column">
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <input
            type="tel"
            name="mobile"
            placeholder="Mobile"
            value={formData.mobile}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Book</button>
      </form>
    </div>
  );
};

export default BookingForm;