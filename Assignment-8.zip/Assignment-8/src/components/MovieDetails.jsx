import React from 'react';
import { useParams, Link } from 'react-router-dom';
import './MovieDetails.css';

const movieData = {
  1: {
    title: 'Avengers',
    description: 'Earth’s mightiest heroes must come together to stop Loki and his alien army.',
    image: 'https://upload.wikimedia.org/wikipedia/en/f/f9/TheAvengers2012Poster.jpg',
  },
  2: {
    title: 'Inception',
    description: 'A skilled thief leads a team to plant an idea inside a target’s subconscious.',
    image: 'https://upload.wikimedia.org/wikipedia/en/7/7f/Inception_ver3.jpg',
  },
  // Add more as needed
};

const MovieDetails = () => {
  const { id } = useParams();
  const movie = movieData[id];

  if (!movie) return <div className="movie-details">Movie not found.</div>;

  return (
    <div className="movie-details">
      <img src={movie.image} alt={movie.title} className="banner" />
      <h1>{movie.title}</h1>
      <p className="description">{movie.description}</p>
      <Link to={`/book/${id}`} className="book-btn">🎟️ Book Now</Link>
    </div>
  );
};

export default MovieDetails;
