import React from 'react';
import './Confirmation.css';

const Confirmation = ({ bookingId, formData, onGoHome }) => {
  return (
    <div className="confirmation-container">
      <h1>✅ Booking Confirmed!</h1>
      <p><strong>Booking ID:</strong> {bookingId}</p>
      <p><strong>Name:</strong> {formData.name}</p>
      <p><strong>Email:</strong> {formData.email}</p>
      <p><strong>Mobile:</strong> {formData.mobile}</p>
      <button onClick={onGoHome}>Go to Home</button>
    </div>
  );
};

export default Confirmation;
