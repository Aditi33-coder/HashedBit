import React from 'react';
import { Link } from 'react-router-dom';
import './MovieList.css';

const movies = [
  {
    id: 1,
    title: 'Avengers',
    image: 'https://upload.wikimedia.org/wikipedia/en/f/f9/TheAvengers2012Poster.jpg',
  },
  {
    id: 2,
    title: 'Inception',
    image: 'https://upload.wikimedia.org/wikipedia/en/7/7f/Inception_ver3.jpg',
  },
  // Add more movie objects here for 4x4 layout
];

const MovieList = () => {
  return (
    <div className="movie-list-container">
      <h1 className="heading">🎬 Movie Booking</h1>
      <div className="movie-grid">
        {movies.map((movie) => (
          <div key={movie.id} className="movie-card">
            <img src={movie.image} alt={movie.title} className="movie-img" />
            <h2 className="movie-title">{movie.title}</h2>
            <Link to={`/movie/${movie.id}`} className="details-link">
              View Details
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MovieList;
